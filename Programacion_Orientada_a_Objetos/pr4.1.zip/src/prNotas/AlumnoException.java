package prNotas;

public class AlumnoException extends Exception{

	public AlumnoException() {
		super();
	}
	
	public AlumnoException(String a) {
		super(a);
	}
}

package prNotas;

public interface CalculoMedia {

	public double calcular(Alumno [] a) throws AlumnoException;
	
}
